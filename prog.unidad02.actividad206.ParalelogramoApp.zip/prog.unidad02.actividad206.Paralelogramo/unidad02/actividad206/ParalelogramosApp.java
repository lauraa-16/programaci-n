package actividad206;

public class ParalelogramosApp {

	public static void main(String[] args) {
		// Solicito por teclado la longitud del lado horizontal
		System.out.println("Introduce ");

	}

}
